using System;

namespace BlogApp.wwwroot.images;

public class images
{

}
